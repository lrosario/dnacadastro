<?php
$valida[admin] = "123porra";
?>